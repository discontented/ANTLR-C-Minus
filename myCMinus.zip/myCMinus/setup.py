from setuptools import setup

setup(
    name = "myCminus",
    install_requires=["antlr4-python3-runtime"]
)