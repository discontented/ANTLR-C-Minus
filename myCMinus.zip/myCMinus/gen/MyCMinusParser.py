# Generated from C:/Users/jcorn/PycharmProjects/python-p4/grammar/ebnf\MyCMinus.g4 by ANTLR 4.7
# encoding: utf-8
from antlr4 import *
from io import StringIO
from typing.io import TextIO
import sys

def serializedATN():
    with StringIO() as buf:
        buf.write("\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3%")
        buf.write("u\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b")
        buf.write("\t\b\3\2\3\2\3\3\3\3\3\3\7\3\26\n\3\f\3\16\3\31\13\3\3")
        buf.write("\4\3\4\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5")
        buf.write("\3\5\3\5\3\5\3\5\3\5\3\5\3\5\5\5\60\n\5\3\6\3\6\3\6\3")
        buf.write("\6\3\6\3\6\3\6\5\69\n\6\3\6\3\6\3\6\3\6\3\6\3\6\5\6A\n")
        buf.write("\6\3\7\3\7\3\7\3\7\5\7G\n\7\3\7\3\7\3\7\3\7\3\7\3\7\3")
        buf.write("\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\5\7W\n\7\3\7\3\7\3\7\3")
        buf.write("\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\7\7h\n")
        buf.write("\7\f\7\16\7k\13\7\3\b\3\b\3\b\7\bp\n\b\f\b\16\bs\13\b")
        buf.write("\3\b\2\3\f\t\2\4\6\b\n\f\16\2\b\3\2\35\"\3\2\24\25\3\2")
        buf.write("\30\33\4\2\27\27\34\34\3\2\17\20\3\2\21\22\2\u0082\2\20")
        buf.write("\3\2\2\2\4\27\3\2\2\2\6\32\3\2\2\2\b/\3\2\2\2\n@\3\2\2")
        buf.write("\2\fV\3\2\2\2\16l\3\2\2\2\20\21\5\4\3\2\21\3\3\2\2\2\22")
        buf.write("\23\5\b\5\2\23\24\7\r\2\2\24\26\3\2\2\2\25\22\3\2\2\2")
        buf.write("\26\31\3\2\2\2\27\25\3\2\2\2\27\30\3\2\2\2\30\5\3\2\2")
        buf.write("\2\31\27\3\2\2\2\32\33\t\2\2\2\33\7\3\2\2\2\34\35\5\6")
        buf.write("\4\2\35\36\7#\2\2\36\60\3\2\2\2\37 \5\6\4\2 !\7#\2\2!")
        buf.write("\"\7\23\2\2\"#\5\f\7\2#\60\3\2\2\2$%\7#\2\2%&\7\23\2\2")
        buf.write("&\60\5\f\7\2\'(\7\6\2\2(\60\5\f\7\2)\60\5\n\6\2*\60\5")
        buf.write("\f\7\2+,\7\t\2\2,-\5\4\3\2-.\7\n\2\2.\60\3\2\2\2/\34\3")
        buf.write("\2\2\2/\37\3\2\2\2/$\3\2\2\2/\'\3\2\2\2/)\3\2\2\2/*\3")
        buf.write("\2\2\2/+\3\2\2\2\60\t\3\2\2\2\61\62\7\3\2\2\62\63\7\7")
        buf.write("\2\2\63\64\5\f\7\2\64\65\7\b\2\2\658\5\b\5\2\66\67\7\4")
        buf.write("\2\2\679\5\b\5\28\66\3\2\2\289\3\2\2\29A\3\2\2\2:;\7\5")
        buf.write("\2\2;<\7\7\2\2<=\5\f\7\2=>\7\b\2\2>?\5\b\5\2?A\3\2\2\2")
        buf.write("@\61\3\2\2\2@:\3\2\2\2A\13\3\2\2\2BC\b\7\1\2CD\7#\2\2")
        buf.write("DF\7\7\2\2EG\5\16\b\2FE\3\2\2\2FG\3\2\2\2GH\3\2\2\2HW")
        buf.write("\7\b\2\2IJ\7#\2\2JK\7\13\2\2KL\5\f\7\2LM\7\f\2\2MW\3\2")
        buf.write("\2\2NO\7\26\2\2OW\5\f\7\13PW\7#\2\2QW\7$\2\2RS\7\7\2\2")
        buf.write("ST\5\f\7\2TU\7\b\2\2UW\3\2\2\2VB\3\2\2\2VI\3\2\2\2VN\3")
        buf.write("\2\2\2VP\3\2\2\2VQ\3\2\2\2VR\3\2\2\2Wi\3\2\2\2XY\f\n\2")
        buf.write("\2YZ\t\3\2\2Zh\5\f\7\13[\\\f\t\2\2\\]\t\4\2\2]h\5\f\7")
        buf.write("\n^_\f\b\2\2_`\t\5\2\2`h\5\f\7\tab\f\7\2\2bc\t\6\2\2c")
        buf.write("h\5\f\7\bde\f\6\2\2ef\t\7\2\2fh\5\f\7\7gX\3\2\2\2g[\3")
        buf.write("\2\2\2g^\3\2\2\2ga\3\2\2\2gd\3\2\2\2hk\3\2\2\2ig\3\2\2")
        buf.write("\2ij\3\2\2\2j\r\3\2\2\2ki\3\2\2\2lq\5\f\7\2mn\7\16\2\2")
        buf.write("np\5\f\7\2om\3\2\2\2ps\3\2\2\2qo\3\2\2\2qr\3\2\2\2r\17")
        buf.write("\3\2\2\2sq\3\2\2\2\13\27/8@FVgiq")
        return buf.getvalue()


class MyCMinusParser ( Parser ):

    grammarFileName = "MyCMinus.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'if'", "'else'", "'while'", "'print'", 
                     "'('", "')'", "'{'", "'}'", "'['", "']'", "';'", "','", 
                     "'+'", "'-'", "'*'", "'/'", "'='", "'&&'", "'||'", 
                     "'!'", "'=='", "'>'", "'>='", "'<'", "'<='", "'!='", 
                     "'int'", "'float'", "'void'", "'string'", "'char'", 
                     "'bool'" ]

    symbolicNames = [ "<INVALID>", "IF", "ELSE", "WHILE", "PRINT", "LPAR", 
                      "RPAR", "LCURL", "RCURL", "LBRAC", "RBRAC", "SEMI", 
                      "COMMA", "PLUS", "MINUS", "TIMES", "DIVIDE", "EQUALS", 
                      "AND", "OR", "NOT", "EQUALTO", "GTHAN", "GEQUAL", 
                      "LTHAN", "LEQUAL", "NOTEQ", "INT", "FLOAT", "VOID", 
                      "STRING", "CHAR", "BOOL", "ID", "NUMBER", "WS" ]

    RULE_program = 0
    RULE_statementList = 1
    RULE_varType = 2
    RULE_statement = 3
    RULE_conditionalStatement = 4
    RULE_expression = 5
    RULE_exprList = 6

    ruleNames =  [ "program", "statementList", "varType", "statement", "conditionalStatement", 
                   "expression", "exprList" ]

    EOF = Token.EOF
    IF=1
    ELSE=2
    WHILE=3
    PRINT=4
    LPAR=5
    RPAR=6
    LCURL=7
    RCURL=8
    LBRAC=9
    RBRAC=10
    SEMI=11
    COMMA=12
    PLUS=13
    MINUS=14
    TIMES=15
    DIVIDE=16
    EQUALS=17
    AND=18
    OR=19
    NOT=20
    EQUALTO=21
    GTHAN=22
    GEQUAL=23
    LTHAN=24
    LEQUAL=25
    NOTEQ=26
    INT=27
    FLOAT=28
    VOID=29
    STRING=30
    CHAR=31
    BOOL=32
    ID=33
    NUMBER=34
    WS=35

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.7")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None



    class ProgramContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def statementList(self):
            return self.getTypedRuleContext(MyCMinusParser.StatementListContext,0)


        def getRuleIndex(self):
            return MyCMinusParser.RULE_program

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProgram" ):
                listener.enterProgram(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProgram" ):
                listener.exitProgram(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProgram" ):
                return visitor.visitProgram(self)
            else:
                return visitor.visitChildren(self)




    def program(self):

        localctx = MyCMinusParser.ProgramContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_program)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 14
            self.statementList()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class StatementListContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MyCMinusParser.StatementContext)
            else:
                return self.getTypedRuleContext(MyCMinusParser.StatementContext,i)


        def SEMI(self, i:int=None):
            if i is None:
                return self.getTokens(MyCMinusParser.SEMI)
            else:
                return self.getToken(MyCMinusParser.SEMI, i)

        def getRuleIndex(self):
            return MyCMinusParser.RULE_statementList

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStatementList" ):
                listener.enterStatementList(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStatementList" ):
                listener.exitStatementList(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStatementList" ):
                return visitor.visitStatementList(self)
            else:
                return visitor.visitChildren(self)




    def statementList(self):

        localctx = MyCMinusParser.StatementListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_statementList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 21
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << MyCMinusParser.IF) | (1 << MyCMinusParser.WHILE) | (1 << MyCMinusParser.PRINT) | (1 << MyCMinusParser.LPAR) | (1 << MyCMinusParser.LCURL) | (1 << MyCMinusParser.NOT) | (1 << MyCMinusParser.INT) | (1 << MyCMinusParser.FLOAT) | (1 << MyCMinusParser.VOID) | (1 << MyCMinusParser.STRING) | (1 << MyCMinusParser.CHAR) | (1 << MyCMinusParser.BOOL) | (1 << MyCMinusParser.ID) | (1 << MyCMinusParser.NUMBER))) != 0):
                self.state = 16
                self.statement()
                self.state = 17
                self.match(MyCMinusParser.SEMI)
                self.state = 23
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class VarTypeContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT(self):
            return self.getToken(MyCMinusParser.INT, 0)

        def FLOAT(self):
            return self.getToken(MyCMinusParser.FLOAT, 0)

        def VOID(self):
            return self.getToken(MyCMinusParser.VOID, 0)

        def BOOL(self):
            return self.getToken(MyCMinusParser.BOOL, 0)

        def STRING(self):
            return self.getToken(MyCMinusParser.STRING, 0)

        def CHAR(self):
            return self.getToken(MyCMinusParser.CHAR, 0)

        def getRuleIndex(self):
            return MyCMinusParser.RULE_varType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVarType" ):
                listener.enterVarType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVarType" ):
                listener.exitVarType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitVarType" ):
                return visitor.visitVarType(self)
            else:
                return visitor.visitChildren(self)




    def varType(self):

        localctx = MyCMinusParser.VarTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_varType)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 24
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << MyCMinusParser.INT) | (1 << MyCMinusParser.FLOAT) | (1 << MyCMinusParser.VOID) | (1 << MyCMinusParser.STRING) | (1 << MyCMinusParser.CHAR) | (1 << MyCMinusParser.BOOL))) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class StatementContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return MyCMinusParser.RULE_statement

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class ConditionalStatContext(StatementContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MyCMinusParser.StatementContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def conditionalStatement(self):
            return self.getTypedRuleContext(MyCMinusParser.ConditionalStatementContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterConditionalStat" ):
                listener.enterConditionalStat(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitConditionalStat" ):
                listener.exitConditionalStat(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitConditionalStat" ):
                return visitor.visitConditionalStat(self)
            else:
                return visitor.visitChildren(self)


    class VarSingleDeclContext(StatementContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MyCMinusParser.StatementContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def varType(self):
            return self.getTypedRuleContext(MyCMinusParser.VarTypeContext,0)

        def ID(self):
            return self.getToken(MyCMinusParser.ID, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVarSingleDecl" ):
                listener.enterVarSingleDecl(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVarSingleDecl" ):
                listener.exitVarSingleDecl(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitVarSingleDecl" ):
                return visitor.visitVarSingleDecl(self)
            else:
                return visitor.visitChildren(self)


    class VarDeclStatContext(StatementContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MyCMinusParser.StatementContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def varType(self):
            return self.getTypedRuleContext(MyCMinusParser.VarTypeContext,0)

        def ID(self):
            return self.getToken(MyCMinusParser.ID, 0)
        def EQUALS(self):
            return self.getToken(MyCMinusParser.EQUALS, 0)
        def expression(self):
            return self.getTypedRuleContext(MyCMinusParser.ExpressionContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVarDeclStat" ):
                listener.enterVarDeclStat(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVarDeclStat" ):
                listener.exitVarDeclStat(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitVarDeclStat" ):
                return visitor.visitVarDeclStat(self)
            else:
                return visitor.visitChildren(self)


    class PrintStatContext(StatementContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MyCMinusParser.StatementContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def PRINT(self):
            return self.getToken(MyCMinusParser.PRINT, 0)
        def expression(self):
            return self.getTypedRuleContext(MyCMinusParser.ExpressionContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrintStat" ):
                listener.enterPrintStat(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrintStat" ):
                listener.exitPrintStat(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPrintStat" ):
                return visitor.visitPrintStat(self)
            else:
                return visitor.visitChildren(self)


    class AssignmentContext(StatementContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MyCMinusParser.StatementContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(MyCMinusParser.ID, 0)
        def EQUALS(self):
            return self.getToken(MyCMinusParser.EQUALS, 0)
        def expression(self):
            return self.getTypedRuleContext(MyCMinusParser.ExpressionContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAssignment" ):
                listener.enterAssignment(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAssignment" ):
                listener.exitAssignment(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAssignment" ):
                return visitor.visitAssignment(self)
            else:
                return visitor.visitChildren(self)


    class BlockContext(StatementContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MyCMinusParser.StatementContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def LCURL(self):
            return self.getToken(MyCMinusParser.LCURL, 0)
        def statementList(self):
            return self.getTypedRuleContext(MyCMinusParser.StatementListContext,0)

        def RCURL(self):
            return self.getToken(MyCMinusParser.RCURL, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBlock" ):
                listener.enterBlock(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBlock" ):
                listener.exitBlock(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBlock" ):
                return visitor.visitBlock(self)
            else:
                return visitor.visitChildren(self)


    class ExpStatContext(StatementContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MyCMinusParser.StatementContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self):
            return self.getTypedRuleContext(MyCMinusParser.ExpressionContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpStat" ):
                listener.enterExpStat(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpStat" ):
                listener.exitExpStat(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpStat" ):
                return visitor.visitExpStat(self)
            else:
                return visitor.visitChildren(self)



    def statement(self):

        localctx = MyCMinusParser.StatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_statement)
        try:
            self.state = 45
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
            if la_ == 1:
                localctx = MyCMinusParser.VarSingleDeclContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 26
                self.varType()
                self.state = 27
                self.match(MyCMinusParser.ID)
                pass

            elif la_ == 2:
                localctx = MyCMinusParser.VarDeclStatContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 29
                self.varType()
                self.state = 30
                self.match(MyCMinusParser.ID)
                self.state = 31
                self.match(MyCMinusParser.EQUALS)
                self.state = 32
                self.expression(0)
                pass

            elif la_ == 3:
                localctx = MyCMinusParser.AssignmentContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 34
                self.match(MyCMinusParser.ID)
                self.state = 35
                self.match(MyCMinusParser.EQUALS)
                self.state = 36
                self.expression(0)
                pass

            elif la_ == 4:
                localctx = MyCMinusParser.PrintStatContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 37
                self.match(MyCMinusParser.PRINT)
                self.state = 38
                self.expression(0)
                pass

            elif la_ == 5:
                localctx = MyCMinusParser.ConditionalStatContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 39
                self.conditionalStatement()
                pass

            elif la_ == 6:
                localctx = MyCMinusParser.ExpStatContext(self, localctx)
                self.enterOuterAlt(localctx, 6)
                self.state = 40
                self.expression(0)
                pass

            elif la_ == 7:
                localctx = MyCMinusParser.BlockContext(self, localctx)
                self.enterOuterAlt(localctx, 7)
                self.state = 41
                self.match(MyCMinusParser.LCURL)
                self.state = 42
                self.statementList()
                self.state = 43
                self.match(MyCMinusParser.RCURL)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ConditionalStatementContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return MyCMinusParser.RULE_conditionalStatement

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class WhileStatementContext(ConditionalStatementContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MyCMinusParser.ConditionalStatementContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def WHILE(self):
            return self.getToken(MyCMinusParser.WHILE, 0)
        def LPAR(self):
            return self.getToken(MyCMinusParser.LPAR, 0)
        def expression(self):
            return self.getTypedRuleContext(MyCMinusParser.ExpressionContext,0)

        def RPAR(self):
            return self.getToken(MyCMinusParser.RPAR, 0)
        def statement(self):
            return self.getTypedRuleContext(MyCMinusParser.StatementContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterWhileStatement" ):
                listener.enterWhileStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitWhileStatement" ):
                listener.exitWhileStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitWhileStatement" ):
                return visitor.visitWhileStatement(self)
            else:
                return visitor.visitChildren(self)


    class IfStatementContext(ConditionalStatementContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MyCMinusParser.ConditionalStatementContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def IF(self):
            return self.getToken(MyCMinusParser.IF, 0)
        def LPAR(self):
            return self.getToken(MyCMinusParser.LPAR, 0)
        def expression(self):
            return self.getTypedRuleContext(MyCMinusParser.ExpressionContext,0)

        def RPAR(self):
            return self.getToken(MyCMinusParser.RPAR, 0)
        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MyCMinusParser.StatementContext)
            else:
                return self.getTypedRuleContext(MyCMinusParser.StatementContext,i)

        def ELSE(self):
            return self.getToken(MyCMinusParser.ELSE, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIfStatement" ):
                listener.enterIfStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIfStatement" ):
                listener.exitIfStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIfStatement" ):
                return visitor.visitIfStatement(self)
            else:
                return visitor.visitChildren(self)



    def conditionalStatement(self):

        localctx = MyCMinusParser.ConditionalStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_conditionalStatement)
        try:
            self.state = 62
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [MyCMinusParser.IF]:
                localctx = MyCMinusParser.IfStatementContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 47
                self.match(MyCMinusParser.IF)
                self.state = 48
                self.match(MyCMinusParser.LPAR)
                self.state = 49
                self.expression(0)
                self.state = 50
                self.match(MyCMinusParser.RPAR)
                self.state = 51
                self.statement()
                self.state = 54
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,2,self._ctx)
                if la_ == 1:
                    self.state = 52
                    self.match(MyCMinusParser.ELSE)
                    self.state = 53
                    self.statement()


                pass
            elif token in [MyCMinusParser.WHILE]:
                localctx = MyCMinusParser.WhileStatementContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 56
                self.match(MyCMinusParser.WHILE)
                self.state = 57
                self.match(MyCMinusParser.LPAR)
                self.state = 58
                self.expression(0)
                self.state = 59
                self.match(MyCMinusParser.RPAR)
                self.state = 60
                self.statement()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ExpressionContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return MyCMinusParser.RULE_expression

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class RelationExpContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MyCMinusParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MyCMinusParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(MyCMinusParser.ExpressionContext,i)

        def LTHAN(self):
            return self.getToken(MyCMinusParser.LTHAN, 0)
        def GTHAN(self):
            return self.getToken(MyCMinusParser.GTHAN, 0)
        def LEQUAL(self):
            return self.getToken(MyCMinusParser.LEQUAL, 0)
        def GEQUAL(self):
            return self.getToken(MyCMinusParser.GEQUAL, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRelationExp" ):
                listener.enterRelationExp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRelationExp" ):
                listener.exitRelationExp(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRelationExp" ):
                return visitor.visitRelationExp(self)
            else:
                return visitor.visitChildren(self)


    class ArithmeticExpContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MyCMinusParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MyCMinusParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(MyCMinusParser.ExpressionContext,i)

        def PLUS(self):
            return self.getToken(MyCMinusParser.PLUS, 0)
        def MINUS(self):
            return self.getToken(MyCMinusParser.MINUS, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArithmeticExp" ):
                listener.enterArithmeticExp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArithmeticExp" ):
                listener.exitArithmeticExp(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitArithmeticExp" ):
                return visitor.visitArithmeticExp(self)
            else:
                return visitor.visitChildren(self)


    class IdCallContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MyCMinusParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(MyCMinusParser.ID, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIdCall" ):
                listener.enterIdCall(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIdCall" ):
                listener.exitIdCall(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIdCall" ):
                return visitor.visitIdCall(self)
            else:
                return visitor.visitChildren(self)


    class UnaryExpContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MyCMinusParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def NOT(self):
            return self.getToken(MyCMinusParser.NOT, 0)
        def expression(self):
            return self.getTypedRuleContext(MyCMinusParser.ExpressionContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUnaryExp" ):
                listener.enterUnaryExp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUnaryExp" ):
                listener.exitUnaryExp(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUnaryExp" ):
                return visitor.visitUnaryExp(self)
            else:
                return visitor.visitChildren(self)


    class EqualityExpContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MyCMinusParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MyCMinusParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(MyCMinusParser.ExpressionContext,i)

        def EQUALTO(self):
            return self.getToken(MyCMinusParser.EQUALTO, 0)
        def NOTEQ(self):
            return self.getToken(MyCMinusParser.NOTEQ, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEqualityExp" ):
                listener.enterEqualityExp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEqualityExp" ):
                listener.exitEqualityExp(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitEqualityExp" ):
                return visitor.visitEqualityExp(self)
            else:
                return visitor.visitChildren(self)


    class ParExpContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MyCMinusParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def LPAR(self):
            return self.getToken(MyCMinusParser.LPAR, 0)
        def expression(self):
            return self.getTypedRuleContext(MyCMinusParser.ExpressionContext,0)

        def RPAR(self):
            return self.getToken(MyCMinusParser.RPAR, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParExp" ):
                listener.enterParExp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParExp" ):
                listener.exitParExp(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParExp" ):
                return visitor.visitParExp(self)
            else:
                return visitor.visitChildren(self)


    class MultExpContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MyCMinusParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MyCMinusParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(MyCMinusParser.ExpressionContext,i)

        def TIMES(self):
            return self.getToken(MyCMinusParser.TIMES, 0)
        def DIVIDE(self):
            return self.getToken(MyCMinusParser.DIVIDE, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMultExp" ):
                listener.enterMultExp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMultExp" ):
                listener.exitMultExp(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMultExp" ):
                return visitor.visitMultExp(self)
            else:
                return visitor.visitChildren(self)


    class FuncCallContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MyCMinusParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(MyCMinusParser.ID, 0)
        def LPAR(self):
            return self.getToken(MyCMinusParser.LPAR, 0)
        def RPAR(self):
            return self.getToken(MyCMinusParser.RPAR, 0)
        def exprList(self):
            return self.getTypedRuleContext(MyCMinusParser.ExprListContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFuncCall" ):
                listener.enterFuncCall(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFuncCall" ):
                listener.exitFuncCall(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFuncCall" ):
                return visitor.visitFuncCall(self)
            else:
                return visitor.visitChildren(self)


    class PrimNumContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MyCMinusParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def NUMBER(self):
            return self.getToken(MyCMinusParser.NUMBER, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrimNum" ):
                listener.enterPrimNum(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrimNum" ):
                listener.exitPrimNum(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPrimNum" ):
                return visitor.visitPrimNum(self)
            else:
                return visitor.visitChildren(self)


    class LogicalExpContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MyCMinusParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MyCMinusParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(MyCMinusParser.ExpressionContext,i)

        def OR(self):
            return self.getToken(MyCMinusParser.OR, 0)
        def AND(self):
            return self.getToken(MyCMinusParser.AND, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLogicalExp" ):
                listener.enterLogicalExp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLogicalExp" ):
                listener.exitLogicalExp(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLogicalExp" ):
                return visitor.visitLogicalExp(self)
            else:
                return visitor.visitChildren(self)


    class ArrayCallContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MyCMinusParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(MyCMinusParser.ID, 0)
        def LBRAC(self):
            return self.getToken(MyCMinusParser.LBRAC, 0)
        def expression(self):
            return self.getTypedRuleContext(MyCMinusParser.ExpressionContext,0)

        def RBRAC(self):
            return self.getToken(MyCMinusParser.RBRAC, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArrayCall" ):
                listener.enterArrayCall(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArrayCall" ):
                listener.exitArrayCall(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitArrayCall" ):
                return visitor.visitArrayCall(self)
            else:
                return visitor.visitChildren(self)



    def expression(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = MyCMinusParser.ExpressionContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 10
        self.enterRecursionRule(localctx, 10, self.RULE_expression, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 84
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,5,self._ctx)
            if la_ == 1:
                localctx = MyCMinusParser.FuncCallContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx

                self.state = 65
                self.match(MyCMinusParser.ID)
                self.state = 66
                self.match(MyCMinusParser.LPAR)
                self.state = 68
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << MyCMinusParser.LPAR) | (1 << MyCMinusParser.NOT) | (1 << MyCMinusParser.ID) | (1 << MyCMinusParser.NUMBER))) != 0):
                    self.state = 67
                    self.exprList()


                self.state = 70
                self.match(MyCMinusParser.RPAR)
                pass

            elif la_ == 2:
                localctx = MyCMinusParser.ArrayCallContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 71
                self.match(MyCMinusParser.ID)
                self.state = 72
                self.match(MyCMinusParser.LBRAC)
                self.state = 73
                self.expression(0)
                self.state = 74
                self.match(MyCMinusParser.RBRAC)
                pass

            elif la_ == 3:
                localctx = MyCMinusParser.UnaryExpContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 76
                self.match(MyCMinusParser.NOT)
                self.state = 77
                self.expression(9)
                pass

            elif la_ == 4:
                localctx = MyCMinusParser.IdCallContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 78
                self.match(MyCMinusParser.ID)
                pass

            elif la_ == 5:
                localctx = MyCMinusParser.PrimNumContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 79
                self.match(MyCMinusParser.NUMBER)
                pass

            elif la_ == 6:
                localctx = MyCMinusParser.ParExpContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 80
                self.match(MyCMinusParser.LPAR)
                self.state = 81
                self.expression(0)
                self.state = 82
                self.match(MyCMinusParser.RPAR)
                pass


            self._ctx.stop = self._input.LT(-1)
            self.state = 103
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,7,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 101
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,6,self._ctx)
                    if la_ == 1:
                        localctx = MyCMinusParser.LogicalExpContext(self, MyCMinusParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 86
                        if not self.precpred(self._ctx, 8):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 8)")
                        self.state = 87
                        _la = self._input.LA(1)
                        if not(_la==MyCMinusParser.AND or _la==MyCMinusParser.OR):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 88
                        self.expression(9)
                        pass

                    elif la_ == 2:
                        localctx = MyCMinusParser.RelationExpContext(self, MyCMinusParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 89
                        if not self.precpred(self._ctx, 7):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 7)")
                        self.state = 90
                        _la = self._input.LA(1)
                        if not((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << MyCMinusParser.GTHAN) | (1 << MyCMinusParser.GEQUAL) | (1 << MyCMinusParser.LTHAN) | (1 << MyCMinusParser.LEQUAL))) != 0)):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 91
                        self.expression(8)
                        pass

                    elif la_ == 3:
                        localctx = MyCMinusParser.EqualityExpContext(self, MyCMinusParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 92
                        if not self.precpred(self._ctx, 6):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 6)")
                        self.state = 93
                        _la = self._input.LA(1)
                        if not(_la==MyCMinusParser.EQUALTO or _la==MyCMinusParser.NOTEQ):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 94
                        self.expression(7)
                        pass

                    elif la_ == 4:
                        localctx = MyCMinusParser.ArithmeticExpContext(self, MyCMinusParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 95
                        if not self.precpred(self._ctx, 5):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 5)")
                        self.state = 96
                        _la = self._input.LA(1)
                        if not(_la==MyCMinusParser.PLUS or _la==MyCMinusParser.MINUS):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 97
                        self.expression(6)
                        pass

                    elif la_ == 5:
                        localctx = MyCMinusParser.MultExpContext(self, MyCMinusParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 98
                        if not self.precpred(self._ctx, 4):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 4)")
                        self.state = 99
                        _la = self._input.LA(1)
                        if not(_la==MyCMinusParser.TIMES or _la==MyCMinusParser.DIVIDE):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 100
                        self.expression(5)
                        pass

             
                self.state = 105
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,7,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx

    class ExprListContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return MyCMinusParser.RULE_exprList

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class ExpressionListContext(ExprListContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MyCMinusParser.ExprListContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MyCMinusParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(MyCMinusParser.ExpressionContext,i)

        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(MyCMinusParser.COMMA)
            else:
                return self.getToken(MyCMinusParser.COMMA, i)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpressionList" ):
                listener.enterExpressionList(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpressionList" ):
                listener.exitExpressionList(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionList" ):
                return visitor.visitExpressionList(self)
            else:
                return visitor.visitChildren(self)



    def exprList(self):

        localctx = MyCMinusParser.ExprListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_exprList)
        self._la = 0 # Token type
        try:
            localctx = MyCMinusParser.ExpressionListContext(self, localctx)
            self.enterOuterAlt(localctx, 1)
            self.state = 106
            self.expression(0)
            self.state = 111
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==MyCMinusParser.COMMA:
                self.state = 107
                self.match(MyCMinusParser.COMMA)
                self.state = 108
                self.expression(0)
                self.state = 113
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[5] = self.expression_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def expression_sempred(self, localctx:ExpressionContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 8)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 7)
         

            if predIndex == 2:
                return self.precpred(self._ctx, 6)
         

            if predIndex == 3:
                return self.precpred(self._ctx, 5)
         

            if predIndex == 4:
                return self.precpred(self._ctx, 4)
         




